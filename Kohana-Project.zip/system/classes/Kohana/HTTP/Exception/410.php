<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana_HTTP_Exception_410 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 410 Gone
	 */
	protected $_code = 410;

}
