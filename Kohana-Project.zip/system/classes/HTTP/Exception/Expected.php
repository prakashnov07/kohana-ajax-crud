<?php defined('SYSPATH') OR die('No direct script access.');

abstract class HTTP_Exception_Expected extends Kohana_HTTP_Exception_Expected {}
