<?php defined('SYSPATH') OR die('No direct script access.');

class Num extends Kohana_Num {}
