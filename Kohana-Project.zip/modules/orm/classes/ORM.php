<?php defined('SYSPATH') OR die('No direct script access.');

class ORM extends Kohana_ORM {}
