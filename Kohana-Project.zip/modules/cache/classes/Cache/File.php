<?php defined('SYSPATH') or die('No direct script access.');

class Cache_File extends Kohana_Cache_File {}