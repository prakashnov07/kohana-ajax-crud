<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2017-03-03 10:44:35 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 158 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Cookie.php:67
2017-03-03 10:44:35 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('XDEBUG_SESSION', NULL)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('XDEBUG_SESSION')
#2 C:\xampp\htdocs\Kohana-Project\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Cookie.php:67
2017-03-03 10:45:02 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 158 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Cookie.php:67
2017-03-03 10:45:02 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('XDEBUG_SESSION', NULL)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('XDEBUG_SESSION')
#2 C:\xampp\htdocs\Kohana-Project\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Cookie.php:67