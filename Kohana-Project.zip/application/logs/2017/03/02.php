<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2017-03-02 15:10:35 --- CRITICAL: ErrorException [ 1 ]: Class 'Model_Post' not found ~ MODPATH\orm\classes\Kohana\ORM.php [ 46 ] in file:line
2017-03-02 15:10:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-03-02 15:33:02 --- CRITICAL: ErrorException [ 1 ]: Class 'Media' not found ~ APPPATH\views\index.php [ 6 ] in file:line
2017-03-02 15:33:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-03-02 16:34:58 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected end of file, expecting function (T_FUNCTION) ~ APPPATH\classes\Controller\index.php [ 16 ] in file:line
2017-03-02 16:34:58 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-03-02 17:15:35 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ SYSPATH\classes\Kohana\Response.php [ 160 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:15:35 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php(160): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 160, Array)
#1 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(10): Kohana_Response->body(Object(Database_MySQLi_Result))
#2 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:15:39 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ SYSPATH\classes\Kohana\Response.php [ 160 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:15:39 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php(160): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 160, Array)
#1 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(10): Kohana_Response->body(Object(Database_MySQLi_Result))
#2 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:16:14 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ SYSPATH\classes\Kohana\Response.php [ 160 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:16:14 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php(160): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 160, Array)
#1 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(10): Kohana_Response->body(Object(Database_MySQLi_Result))
#2 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:16:56 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ SYSPATH\classes\Kohana\Response.php [ 160 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:16:56 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php(160): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 160, Array)
#1 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(10): Kohana_Response->body(Object(Database_MySQLi_Result))
#2 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:17:43 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ SYSPATH\classes\Kohana\Response.php [ 160 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:17:43 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php(160): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 160, Array)
#1 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(10): Kohana_Response->body(Object(Database_MySQLi_Result))
#2 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:17:49 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ SYSPATH\classes\Kohana\Response.php [ 160 ] in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:17:49 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php(160): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 160, Array)
#1 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(10): Kohana_Response->body(Object(Database_MySQLi_Result))
#2 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Response.php:160
2017-03-02 17:18:27 --- CRITICAL: ErrorException [ 8 ]: Use of undefined constant title - assumed 'title' ~ APPPATH\classes\Controller\index.php [ 10 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:10
2017-03-02 17:18:27 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(10): Kohana_Core::error_handler(8, 'Use of undefine...', 'C:\\xampp\\htdocs...', 10, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:10
2017-03-02 17:23:49 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Database_MySQLi_Result::$as_array ~ APPPATH\classes\Controller\index.php [ 14 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:14
2017-03-02 17:23:49 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(14): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\xampp\\htdocs...', 14, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:14
2017-03-02 17:23:56 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Database_MySQLi_Result::$as_array ~ APPPATH\classes\Controller\index.php [ 14 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:14
2017-03-02 17:23:56 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(14): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\xampp\\htdocs...', 14, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:14
2017-03-02 17:57:47 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ APPPATH\classes\Controller\index.php [ 26 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 17:57:47 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(26): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 26, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_getdata()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 17:57:50 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ APPPATH\classes\Controller\index.php [ 26 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 17:57:50 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(26): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 26, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_getdata()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 17:58:02 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ APPPATH\classes\Controller\index.php [ 26 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 17:58:02 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(26): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 26, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_getdata()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 17:58:14 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ APPPATH\classes\Controller\index.php [ 26 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 17:58:14 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(26): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 26, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_getdata()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 18:27:42 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ APPPATH\classes\Controller\index.php [ 26 ] in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 18:27:42 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(26): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\xampp\\htdocs...', 26, Array)
#1 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_getdata()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php:26
2017-03-02 18:58:20 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\Controller\index.php [ 31 ] in file:line
2017-03-02 18:58:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-03-02 19:10:42 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\Controller\index.php [ 31 ] in file:line
2017-03-02 19:10:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-03-02 20:45:50 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'public' (T_PUBLIC) ~ APPPATH\classes\Controller\index.php [ 87 ] in file:line
2017-03-02 20:45:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-03-02 21:03:49 --- CRITICAL: ErrorException [ 1 ]: Class 'Image' not found ~ APPPATH\classes\Controller\index.php [ 72 ] in file:line
2017-03-02 21:03:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-03-02 22:05:18 --- CRITICAL: Database_Exception [ 1292 ]: Incorrect date value: '02-03-2017-10-05-18-pm' for column 'date_added' at row 1 [ INSERT INTO `records` (`title`, `filename`, `imgpath`, `date_added`) VALUES ('Fourth Book', 'fourth_book', '8xuqocpo8syy5ldbthhk.jpg', '02-03-2017-10-05-18-pm') ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\xampp\htdocs\Kohana-Project\modules\database\classes\Kohana\Database\Query.php:251
2017-03-02 22:05:18 --- DEBUG: #0 C:\xampp\htdocs\Kohana-Project\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(2, 'INSERT INTO `re...', false, Array)
#1 C:\xampp\htdocs\Kohana-Project\modules\orm\classes\Kohana\ORM.php(1324): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\xampp\htdocs\Kohana-Project\modules\orm\classes\Kohana\ORM.php(1421): Kohana_ORM->create(NULL)
#3 C:\xampp\htdocs\Kohana-Project\application\classes\Controller\index.php(50): Kohana_ORM->save()
#4 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Controller.php(84): Controller_Index->action_upload()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#7 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\Kohana-Project\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\Kohana-Project\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\Kohana-Project\modules\database\classes\Kohana\Database\Query.php:251