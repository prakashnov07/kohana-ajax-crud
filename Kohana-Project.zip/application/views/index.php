<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Project</title>
	<link rel="stylesheet" href="<?php echo URL::base().'assets/css/bootstrap.min.css' ?>">
</head>
<body>
	<div class="container-fluid">
		<div class="row"><div class="col-sm-2">
		<button type="button" class="btn btn-info btn-block" style="margin-top:15px" onclick="newrecord();">Add New Record</button></div>
<div class="col-sm-10 h3">Record List</div>
		</div>

<table class="table table-bordered table-striped">
<tr>
<th></th>
	<th>Title</th>
	<th>File Name</th>
	<th>Image</th><th></th>
</tr>
<tbody id='recorddatalist'>
	
</tbody>

	
</table>

	</div>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Records</h4>
      </div>
      <div class="modal-body">
      <form id="myform" method="post"  enctype="multipart/form-data">
  <div class="form-group">
    <label for="title">Title:</label>
    <input type="text" class="form-control" id="title" name="title" autofocus required>
    <input type="hidden" class="form-control" id="hiddenid" name="hiddenid" readonly>
  </div>
  <div class="form-group">
    <label for="filename">File Name:</label>
    <input type="text" class="form-control" id="filename" name="filename" required>
  </div>
  <div class="form-group">
      <div class="row">
      <div class="col-sm-6">
    <label for="file">Image:</label>
    <input type="file" id="avatar" name="avatar">
      </div> <div class="col-sm-6"><div id="image_preview"> <img id="previewing" src="" width="100px"/>&nbsp;
                                 
                                
                                
                             </div></div>
    </div>
  </div>
          <div class="form-group"> <span class="text-danger" id="message"></span></div>
  <button type="submit" class="btn btn-info">Submit</button>
</form>
 </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
	<script src="<?php echo URL::base().'assets/js/jquery.min.js' ?>"></script>
	<script src="<?php echo URL::base().'assets/js/bootstrap.min.js' ?>"></script>
		<script>
		
$.ajax({

type : 'post',
url : 'Index/getdata',
 data: "",
 dataType: "json",
success : function (data) { 
	  $.each(data, function (index, dataa) { var i= index+1; var av= dataa.id +','+dataa.title+','+dataa.imgpath+','+dataa.filename;  var img= '<img src= "'+dataa.imgpath+'" width="50px"/>';
                    $('#recorddatalist').append('<tr><td style="width:5%">'+i+'</td><td>'+dataa.title+'</td><td>'+dataa.filename+'</td><td>'+img+'</td><td style="width:10%"><a id="'+av+'" style="margin-right:10px" href="#" title="Edit Record" class="btn btn-success btn-sm" onclick="editdetails(this);"><span class="glyphicon glyphicon- glyphicon-edit"></span></a><a id="'+dataa.id+'" title="Delete Record" href="#" class="btn btn-danger btn-sm" onclick="deletedetails(this)"><span class="glyphicon glyphicon- glyphicon-remove"></span></a></td></tr>');
                 });
}


});



function editdetails(rb)
{
	var data= rb.id;
	 var datas= data.toString().split(',');
	 $('#hiddenid').val(datas[0]);$('#title').val(datas[1]);$('#filename').val(datas[3]);
         $('#previewing').attr('src',datas[2]);
	 $('#myModal').modal({backdrop:'static'});
}

function deletedetails(rb)
{
	var dataid= rb.id;
        
        $.ajax({

type : 'get',
url : 'Index/deletedata',
 data: {id:dataid},
 dataType: "json",
success : function (data) { $('#recorddatalist').empty();
	  $.each(data, function (index, dataa) { var i= index+1; var av= dataa.id +','+dataa.title+','+dataa.imgpath+','+dataa.filename;  var img= '<img src= "'+dataa.imgpath+'" width="50px"/>';
                    $('#recorddatalist').append('<tr><td style="width:5%">'+i+'</td><td>'+dataa.title+'</td><td>'+dataa.filename+'</td><td>'+img+'</td><td style="width:10%"><a id="'+av+'" style="margin-right:10px" href="#" title="Edit Record" class="btn btn-success btn-sm" onclick="editdetails(this);"><span class="glyphicon glyphicon- glyphicon-edit"></span></a><a id="'+dataa.id+'" onclick="deletedetails(this)" title="Delete Record" href="#" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon- glyphicon-remove"></span></a></td></tr>');
                 });
}


});
	
}

function newrecord(){
$('#myform')[0].reset();$('#hiddenid').val('');$('#previewing').attr('src','');
$('#myModal').modal({backdrop:'static'});
}

$("#avatar").change(function() {
$("#message").empty(); // To remove the previous error message
var file = this.files[0];
var imagefile = file.type;
var match= ["image/jpeg","image/png","image/jpg"];
if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
{
$('#previewing').attr('src','');
$("#message").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
$("#avatar").val("");
return false;
}
else
{
var reader = new FileReader();
reader.onload = imageIsLoaded;
reader.readAsDataURL(this.files[0]);
}
});

function imageIsLoaded(e) {
$("#avatar").css("color","green");
$('#image_preview').css("display", "block");
$('#previewing').attr('src', e.target.result);
};


$('#myform').submit( 
function(e) { e.preventDefault();
var hiddenid= $('#hiddenid').val();
if(hiddenid==''){
	$.ajax({


type : 'post',
url : 'Index/upload',
data : new FormData($('#myform')[0]),
dataType: 'json',
 processData: false,
    contentType: false,
success : function (data) {
	$('#recorddatalist').empty();
	 $.each(data, function (index, dataa) { var i= index+1; var av= dataa.id +','+dataa.title+','+dataa.imgpath+','+dataa.filename; var img= '<img src= "'+dataa.imgpath+'" width="50px"/>';
                    $('#recorddatalist').append('<tr><td style="width:5%">'+i+'</td><td>'+dataa.title+'</td><td>'+dataa.filename+'</td><td>'+img+'</td><td style="width:10%"><a id="'+av+'"  style="margin-right:10px"  href="#" title="Edit Record" class="btn btn-success btn-sm" onclick="editdetails(this);"><span class="glyphicon glyphicon- glyphicon-edit"></span></a><a id="'+dataa.id+'" onclick="deletedetails(this)" title="Delete Record" href="#" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon- glyphicon-remove"></span></a></td></tr>');
                 });

	 $('#myModal').modal('hide'); 
	 $('#myform')[0].reset();$('#hiddenid').val('');$('#previewing').attr('src','');
}


});}

	else{
		$.ajax({


type : 'post',
url : 'Index/editupload',
data : new FormData($('#myform')[0]),
dataType: 'json',
 processData: false,
    contentType: false,
success : function (data) {
	$('#recorddatalist').empty();
	 $.each(data, function (index, dataa) { var i= index+1; var av= dataa.id +','+dataa.title+','+dataa.imgpath+','+dataa.filename; var img= '<img src= "'+dataa.imgpath+'" width="50px"/>';
                    $('#recorddatalist').append('<tr><td style="width:5%">'+i+'</td><td>'+dataa.title+'</td><td>'+dataa.filename+'</td><td>'+img+'</td><td style="width:10%"><a id="'+av+'"  style="margin-right:10px"  href="#" title="Edit Record" class="btn btn-success btn-sm" onclick="editdetails(this);"><span class="glyphicon glyphicon- glyphicon-edit"></span></a><a id="'+dataa.id+'" onclick="deletedetails(this)" title="Delete Record" href="#" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon- glyphicon-remove"></span></a></td></tr>');
                 });

	 $('#myModal').modal('hide'); 
	 $('#myform')[0].reset();$('#hiddenid').val('');$('#previewing').attr('src','');
}


});
	}

}


	);






		</script>
</body>
</html>