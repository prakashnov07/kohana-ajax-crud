<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>All Data</title>
        
        <script>
        window.location="http://localhost/Kohana-Project/index.php/index";
        </script>
</head>
<body>

<table>
	<?php 
foreach($posts as $post){   ?>

<tr>
	<td><?= $post->title ?></td>
	<td><?= $post->filename?></td>
</tr>
<?php }  ?>

 

</table>

</body>
</html>