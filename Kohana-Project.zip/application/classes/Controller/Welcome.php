<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Welcome extends Controller {

	public function action_index()
	{
		$records= ORM::factory('Record')->find_all();

		$view= View::factory('welcome')->bind('posts',$records);
		$this->response->body($view);
	}

} // End Welcome
