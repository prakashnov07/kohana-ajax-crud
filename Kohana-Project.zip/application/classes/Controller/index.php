<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Index extends Controller{


public function action_index()
{

$records= ORM::factory('Record')->order_by('id','desc')->find_all();
$view= View::factory('index');
$this->response->body($view);

}

public function action_deletedata()
{
    $cid= $_GET['id'];
    $record= ORM::factory('Record',$cid);
    $record->delete();
    $this->action_getdata();
}


public function action_getdata()
{

$records= ORM::factory('Record')->order_by('id','desc')->find_all();

$json = array();
foreach ($records as $image)
{
    $json[] = $image->as_array();
}

echo json_encode($json);

}


public function action_editupload()
    {
      //  $view = View::factory('avatar/upload');
        $error_message = NULL;
        $filename = NULL;

        $cid= $_POST['hiddenid'];

         $time=date('Y-m-d');
 
        if ($this->request->method() == Request::POST)
        {
            if (isset($_FILES['avatar']))
            {
                $filename = $this->_save_image($_FILES['avatar']);

                if($filename)
                {

$record= ORM::factory('Record',$cid);
$record->title= $_POST['title']; $record->filename= $_POST['filename']; $record->imgpath= URL::base().'uploads/'.$filename; 
$record->save();

$this->action_getdata();


                }
                  else{

$record= ORM::factory('Record',$cid);
$record->title= $_POST['title']; $record->filename= $_POST['filename'];// $record->imgpath= URL::base().'uploads/'.$filename; 
//$record->date_added= $time;
$record->save();

$this->action_getdata();

            }
            }

          
        }
 
        if ( ! $filename)
        {
            $error_message = 'There was a problem while uploading the image.
                Make sure it is uploaded and must be JPG/PNG/GIF file.';
        }
 
       // $view->uploaded_file = $filename;
       // $view->error_message = $error_message;
      //  $this->response->body($view);
    }
 


public function action_upload()
    {
      //  $view = View::factory('avatar/upload');
        $error_message = NULL;
        $filename = NULL;

         $time=date('Y-m-d');
 
        if ($this->request->method() == Request::POST)
        {
            if (isset($_FILES['avatar']))
            {
                $filename = $this->_save_image($_FILES['avatar']);

                if($filename)
                {

$record= ORM::factory('Record');
$record->title= $_POST['title']; $record->filename= $_POST['filename']; $record->imgpath= URL::base().'uploads/'.$filename; $record->date_added= $time;
$record->save();

$this->action_getdata();


                }
                 else
                {

$record= ORM::factory('Record');
$record->title= $_POST['title']; $record->filename= $_POST['filename']; $record->imgpath=''; $record->date_added= $time;
$record->save();

$this->action_getdata();


                }
            }
        }
 
        if ( ! $filename)
        {
            $error_message = 'There was a problem while uploading the image.
                Make sure it is uploaded and must be JPG/PNG/GIF file.';
        }
 
       // $view->uploaded_file = $filename;
       // $view->error_message = $error_message;
      //  $this->response->body($view);
    }
 
    protected function _save_image($image)
    {
        if (
            ! Upload::valid($image) OR
            ! Upload::not_empty($image) OR
            ! Upload::type($image, array('jpg', 'jpeg', 'png', 'gif')))
        {
            return FALSE;
        }
 
        $directory = DOCROOT.'uploads/';
 
        if ($file = Upload::save($image, NULL, $directory))
        {
            $filename = strtolower(Text::random('alnum', 20)).'.jpg';
 
            Image::factory($file)
                ->resize(200, 200, Image::AUTO)
                ->save($directory.$filename);
 
            
            unlink($file);
 
            return $filename;
        }
 
        return FALSE;
    }
 


public function action_done()
{

$this->response->body('done');


}


}
